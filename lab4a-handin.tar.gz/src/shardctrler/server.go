package shardctrler

import (
	"6.5840/raft"
	"bytes"
	"math/rand"
	"time"
)
import "6.5840/labrpc"
import "sync"
import "6.5840/labgob"

type ShardCtrler struct {
	mu        sync.Mutex
	wmu       sync.Mutex
	me        int
	rf        *raft.Raft
	applyCh   chan raft.ApplyMsg
	persister *raft.Persister

	// Your data here.
	ConfigNumber int
	configs []Config // indexed by config num
	dmap map[int64]bool // map for duplicated operation
}

// Op command for raft to make agreement
// captital first letter
type Op struct {
	// Your data here.
	ConfigX Config      
	CId     int        
	ID      int64      
	Kind    string 
}

func (sc *ShardCtrler) MakeSnapshot() []byte {
	var snapshot struct {
		ConfigNumber int
		Configs      []struct {
			Num    int
			Shards [NShards]int
			Groups map[int][]string
		}
		DMapKeys []int64
	}

	sc.mu.Lock()
	defer sc.mu.Unlock()

	snapshot.ConfigNumber = sc.ConfigNumber
	snapshot.Configs = make([]struct {
		Num    int
		Shards [NShards]int
		Groups map[int][]string
	}, len(sc.configs))

	for i, cfg := range sc.configs {
		snapshot.Configs[i] = struct {
			Num    int
			Shards [NShards]int
			Groups map[int][]string
		}{
			Num:    cfg.Num,
			Shards: cfg.Shards,
			Groups: cfg.Groups,
		}
	}

	snapshot.DMapKeys = make([]int64, 0, len(sc.dmap))
	for k := range sc.dmap {
		snapshot.DMapKeys = append(snapshot.DMapKeys, k)
	}

	w := new(bytes.Buffer)
	e := labgob.NewEncoder(w)
	e.Encode(snapshot)

	return w.Bytes()
}


func (sc *ShardCtrler) RestoreSnapshot(data []byte) {
	if data == nil || len(data) == 0 {
		return
	}

	var snapshot struct {
		ConfigNumber int
		Configs      []Config
	}

	r := bytes.NewBuffer(data)
	d := labgob.NewDecoder(r)

	if d.Decode(&snapshot) != nil {
		return
	}

	sc.mu.Lock()
	defer sc.mu.Unlock()

	sc.dmap = make(map[int64]bool)
	sc.configs = snapshot.Configs
	sc.ConfigNumber = snapshot.ConfigNumber
}


func ShardTiming(config2 Config) [NShards]int {
	var res [NShards]int

	gids := make([]int, 0, len(config2.Groups))
	for k := range config2.Groups {
		gids = append(gids, k)
	}

	if len(gids) > 0 {
		for i := range res {
			res[i] = gids[i%len(gids)]
		}
	} else {
		for i := range res {
			res[i] = 0
		}
	}

	return res
}


// WaitAndApply it may use when locked, and the return status is still locked...
// if leader, wait until agreement or return not leader if timeout
// if follower, return immediately
// @args:  cmd
// @reply : wrongleader
func (sc *ShardCtrler) WaitAndApply(cmd Op) (bool, Config) {
	_, _, ok := sc.rf.Start(cmd)
	if !ok {
		return true, Config{}
	}

	startTime := time.Now()
	for !sc.dmap[cmd.ID] && time.Now().Sub(startTime) < 2*time.Second {
		sc.mu.Unlock()
		ms := 10 + rand.Int()%10
		time.Sleep(time.Duration(ms) * time.Millisecond)
		sc.mu.Lock()
	}

	if sc.dmap[cmd.ID] {
		if cmd.Kind == "query" {
			resConfig := ConfigDeepCopy(sc.configs[len(sc.configs)-1])
			if cmd.CId >= 0 && cmd.CId < len(sc.configs) {
				resConfig = ConfigDeepCopy(sc.configs[cmd.CId])
			}
			resConfig.Num--
			return false, resConfig
		}
		return false, Config{}
	}

	return true, Config{}
}


// Join (servers) -- add a set of groups (gid -> server-list mapping).
// will increase a new config finally
func (sc *ShardCtrler) Join(args *JoinArgs, reply *JoinReply) {
	sc.wmu.Lock()
	defer sc.wmu.Unlock()

	sc.mu.Lock()
	defer sc.mu.Unlock()

	_, isLeader := sc.rf.GetState()
	if !isLeader {
		reply.WrongLeader = true
		return
	}

	if sc.dmap[args.ID] {
		reply.WrongLeader = false
		return
	}

	newConfig := sc.createConfigCopy()

	for k, v := range args.Servers {
		newConfig.Groups[k] = v
	}
	newConfig.Shards = ShardTiming(newConfig)

	cmd := Op{
		ConfigX: newConfig,
		ID:      args.ID,
		Kind:    "join",
	}
	reply.WrongLeader, _ = sc.WaitAndApply(cmd)
}

// Leave(gids) -- delete a set of groups.
// will increase a new config finally
func (sc *ShardCtrler) Leave(args *LeaveArgs, reply *LeaveReply) {
	sc.wmu.Lock()
	defer sc.wmu.Unlock()

	sc.mu.Lock()
	defer sc.mu.Unlock()

	_, isLeader := sc.rf.GetState()
	if !isLeader {
		reply.WrongLeader = true
		return
	}

	if sc.dmap[args.ID] {
		reply.WrongLeader = false
		return
	}

	newConfig := sc.createConfigCopy()

	for _, vic := range args.GIDs {
		delete(newConfig.Groups, vic)
	}
	newConfig.Shards = ShardTiming(newConfig)

	cmd := Op{
		ConfigX: newConfig,
		ID:      args.ID,
		Kind:    "leave",
	}
	reply.WrongLeader, _ = sc.WaitAndApply(cmd)
}

// Move(shard, gid) -- hand off one shard from current owner to gid.
// will increase a new config finally
func (sc *ShardCtrler) Move(args *MoveArgs, reply *MoveReply) {
	sc.wmu.Lock()
	defer sc.wmu.Unlock()

	sc.mu.Lock()
	defer sc.mu.Unlock()

	_, isLeader := sc.rf.GetState()
	if !isLeader {
		reply.WrongLeader = true
		return
	}

	if sc.dmap[args.ID] {
		reply.WrongLeader = false
		return
	}

	newConfig := sc.createConfigCopy()
	newConfig.Shards[args.Shard] = args.GID

	cmd := Op{
		ConfigX: newConfig,
		ID:      args.ID,
		Kind:    "move",
	}
	reply.WrongLeader, _ = sc.WaitAndApply(cmd)
}

func (sc *ShardCtrler) createConfigCopy() Config {
	return ConfigDeepCopy(sc.configs[sc.ConfigNumber])
}

func (sc *ShardCtrler) Query(args *QueryArgs, reply *QueryReply) {
	sc.mu.Lock()
	defer sc.mu.Unlock()

	_, isLeader := sc.rf.GetState()
	if !isLeader {
		reply.WrongLeader = true
		return
	}

	if sc.dmap[args.ID] {
		reply.WrongLeader = false
		return
	}

	cmd := Op{
		CId:  args.Num,
		ID:   args.ID,
		Kind: "query",
	}
	reply.WrongLeader, reply.Config = sc.WaitAndApply(cmd)
}


// the tester calls Kill() when a ShardCtrler instance won't
// be needed again. you are not required to do anything
// in Kill(), but it might be convenient to (for example)
// turn off debug output from this instance.
func (sc *ShardCtrler) Kill() {
	sc.rf.Kill()
	// Your code here, if desired.
}

// needed by shardkv tester
func (sc *ShardCtrler) Raft() *raft.Raft {
	return sc.rf
}

func (sc *ShardCtrler) Applier(applyCh chan raft.ApplyMsg) {
	for msg := range applyCh {
		if msg.CommandValid {
			sc.mu.Lock()
			AppliedCmd := msg.Command.(Op)
			if !sc.dmap[AppliedCmd.ID] {
				sc.dmap[AppliedCmd.ID] = true
				if AppliedCmd.Kind != "query" {
					sc.updateConfigs(AppliedCmd.ConfigX)
					sc.ConfigNumber++
				}
			}
			sc.mu.Unlock()
		}
	}
}

func (sc *ShardCtrler) updateConfigs(newConfig Config) {
	if len(sc.configs)-1 >= newConfig.Num {
		sc.configs[newConfig.Num] = newConfig
	} else { 
		for len(sc.configs) < newConfig.Num {
			sc.configs = append(sc.configs, Config{})
		}
		sc.configs = append(sc.configs, newConfig)
	}
}

// servers[] contains the ports of the set of
// servers that will cooperate via Raft to
// form the fault-tolerant shardctrler service.
// me is the index of the current server in servers[].
func StartServer(servers []*labrpc.ClientEnd, me int, persister *raft.Persister) *ShardCtrler {
	sc := &ShardCtrler{
		me:           me,
		persister:   persister,
		configs:      make([]Config, 1),
		ConfigNumber: 0,
		dmap:         make(map[int64]bool),
		applyCh:      make(chan raft.ApplyMsg),
	}
	for i := 0; i < NShards; i++ { 
		sc.configs[0].Shards[i] = 0
	}

	for i := 0; i < NShards; i++ {
		sc.configs[0].Shards[i] = 0
	}

	labgob.Register(Op{})
	sc.rf = raft.Make(servers, me, persister, sc.applyCh)

	go sc.Applier(sc.applyCh)
	return sc
}